select p.PoziomId,p.Nazwa,count(*) ilosc from Danes d
join Pozioms p on d.PoziomId=p.PoziomId
group by p.PoziomId,p.Nazwa