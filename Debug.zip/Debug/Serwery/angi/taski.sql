select j.Id,j.Text,jt.StartTime,jt.EndTime
from jobs j
left join jobtimes jt on j.Id=jt.JobId
order by j.Text,jt.StartTime