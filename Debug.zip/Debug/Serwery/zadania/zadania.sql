select j.*,jt.StartTime,jt.EndTime from jobs j
left join JobTimes jt on jt.JobId=j.Id
order by j.Id,jt.StartTime